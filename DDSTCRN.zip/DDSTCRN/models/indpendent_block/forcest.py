import torch
import torch.nn as nn
from .ind_block import DGCRM
from .ind_model import DDGCRNCell
class DDGCRN(nn.Module):
    def __init__(self, args):
        super(DDGCRN, self).__init__()
        self.num_node = args.num_nodes
        self.input_dim = args.input_dim
        self.hidden_dim = args.rnn_units
        self.output_dim = args.output_dim
        self.horizon = args.horizon
        self.num_layers = args.num_layers
        self.use_D = args.use_day
        self.use_W = args.use_week
        self.dropout1 = nn.Dropout(p=0.1)
        self.dropout2 = nn.Dropout(p=0.1)
        self.default_graph = args.default_graph
        self.node_embeddings1 = nn.Parameter(torch.randn(self.num_node, args.embed_dim), requires_grad=True)
        self.node_embeddings2 = nn.Parameter(torch.randn(self.num_node, args.embed_dim), requires_grad=True)
        self.T_i_D_emb = nn.Parameter(torch.empty(288, args.embed_dim))
        self.D_i_W_emb = nn.Parameter(torch.empty(7, args.embed_dim))

        self.encoder1 = DGCRM(args.num_nodes, args.input_dim, args.rnn_units, args.cheb_k,
                              args.embed_dim, args.num_layers)
        self.encoder2 = DGCRM(args.num_nodes, args.input_dim, args.rnn_units, args.cheb_k,
                              args.embed_dim, args.num_layers)

        self.end_conv1 = nn.Conv2d(1, args.horizon * self.output_dim, kernel_size=(1, self.hidden_dim), bias=True)
        self.end_conv2 = nn.Conv2d(1, args.horizon * self.output_dim, kernel_size=(1, self.hidden_dim), bias=True)
        self.end_conv3 = nn.Conv2d(1, args.horizon * self.output_dim, kernel_size=(1, self.hidden_dim), bias=True)

    def forward(self, source, i=2):
        node_embedding1 = self.node_embeddings1
        if self.use_D:
            t_i_d_data = source[..., 1]

            # T_i_D_emb = self.T_i_D_emb[(t_i_d_data[:, -1, :] * 288).type(torch.LongTensor)]
            T_i_D_emb = self.T_i_D_emb[(t_i_d_data * 288).type(torch.LongTensor)]
            node_embedding1 = torch.mul(node_embedding1, T_i_D_emb)

        if self.use_W:
            d_i_w_data = source[..., 2]
            D_i_W_emb = self.D_i_W_emb[(d_i_w_data).type(torch.LongTensor)]
            node_embedding1 = torch.mul(node_embedding1, D_i_W_emb)

        node_embeddings = [node_embedding1, self.node_embeddings1]

        source = source[..., 0].unsqueeze(-1)
        if i == 1:
            init_state1 = self.encoder1.init_hidden(source.shape[0])
            output, _ = self.encoder1(source, init_state1, node_embeddings)
            output = self.dropout1(output[:, -1:, :, :])
            output1 = self.end_conv1(output)
            return output1
        else:
            init_state1 = self.encoder1.init_hidden(source.shape[0])
            output, _ = self.encoder1(source, init_state1, node_embeddings)
            output = self.dropout1(output[:, -1:, :, :])
            output1 = self.end_conv1(output)
            source1 = self.end_conv2(output)
            source2 = source - source1
            init_state2 = self.encoder2.init_hidden(source2.shape[0])
            output2, _ = self.encoder2(source2, init_state2, node_embeddings)
            output2 = self.dropout2(output2[:, -1:, :, :])
            output2 = self.end_conv3(output2)
            return output1 + output2